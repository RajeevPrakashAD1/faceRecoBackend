const mongoose = require('mongoose');

const Pokemon = require('./pokemonSchema');
const  AppError =  require("../util/errorCreating");

const catchAsync = fn => {
    return (req,res,next) =>{
        fn(req,res,next).catch(err => next(err));
    }
}

exports.createPokemon = catchAsync (async (req, res,next) => {

		const newPokemon = await Pokemon.create(req.body);
		res.send({
			status: 'sucess',
			data: {
				pokemon: newPokemon
			}
		});

		// res.status(201).jason({
		// 	status: 'success',
		// 	data: {
		// 		pokemon: newPokemon
		// 	}
		// });
	
});

exports.getAllPokemon = catchAsync (async (req, res,next) => {
	queryObject = { ...req.query };
	excludefield = [ 'page', 'sort', 'limit' ];
	excludefield.forEach((el) => delete queryObject[el]);

	//advance query filter

	let queryStr = JSON.stringify(queryObject);
	queryStr = queryStr.replace(/\b(gt|gte|lt|lte)\b/g, (match) => `$${match}`);
	const qo = JSON.parse(queryStr);
	console.log('qury string object', qo);

	console.log('query req', req.query);

	// try {


		const pokemons = await Pokemon.find(qo);

        if(pokemons.length == 0){
            console.log("no pokemon found");

            return (new AppError("No Pokemon with this name",404));
        }

		res.send({
			status: 'sucess',
			length: pokemons.length,
			data: {
				pokemons
			}
		});

		res.status(200);



	// } catch (err) {
	// 	res.send(err);
	// 	console.log(err);
	// }
});

exports.getPokemonByName =   catchAsync( async   (req, res,next) => {

        

		const pokemon = await Pokemon.find({ name: req.params.name });
		if(pokemon.length == 0){
            console.log("no pokemon found");

            return next(new AppError("No Pokemon with this name",404));
        }

		res.send({
			status: 'sucess',
			data: { pokemon }
		});

});

exports.updatePokemonByName = catchAsync( async (req, res) => {
	try {
		const pokemon = await Pokemon.findOneAndUpdate({ name: req.params.name }, req.body, {
			new: true,
			validator: true
		});
		res.send({
			pokemon
		});
	} catch (err) {
		console.log(err);
		res.send(err);
	}
});

exports.getPokemonStats = async (req, res) => {
	try {
		const stats = await Pokemon.aggregate([
			{ $match: { power: { $gte: 30 } } },
			{
				$group: {
					_id: null,

					averagePower: { $avg: '$power' },
					maxPower: { $max: '$power' }
				}
			}
            
		]);
        res.send({stats})
	} catch (err) {
		console.log(err);
		res.send(err);
	}
};


//rajeev  api