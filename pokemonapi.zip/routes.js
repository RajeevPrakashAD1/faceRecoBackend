const express = require('express');
const userController = require('./users/userController');

const router = express.Router();
const pokemonController = require('./pokemon/pokemondbController');
const authController = require('./authcontroller/authcontroller')

// router.param('id', userController.checkID);












router
    .route("/forgetPassword")
    .post(authController.forgetPassword);
router
    .route("/resetPassword")
    .post(authController.resetPassword);

router
  .route('/pokemons')
  
  .post(pokemonController.createPokemon)
  .get(pokemonController.getAllPokemon)

router
    .route('/pokemons/:name')
    .get(pokemonController.getPokemonByName)
    .patch(pokemonController.updatePokemonByName)


router
    .route("/stats")
    .get(pokemonController.getPokemonStats)



router
    .route("/users")
    .get(userController.getAllUsers)
router
    .route("/signup")
    .post(userController.createUser)


router.
    route("/login")
    .post(authController.protect,authController.login)




module.exports = router;