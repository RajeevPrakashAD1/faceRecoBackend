const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const mongoose = require('mongoose');

const pokemonRoutes = require('./routes');

const app = express();
app.set('view engine', 'ejs');

app.use(bodyParser.json());

app.use(
	bodyParser.urlencoded({
		extended: true
	})
);

const connectString =
	'mongodb+srv://youtube:e17pk2110064@cluster0.hslb9.mongodb.net/pokemonDB?retryWrites=true&w=majority';
app.use(express.static('public'));

mongoose
	.connect(connectString, {
		useNewUrlParser: true,
		useUnifiedTopology: true,
		useFindAndModify: false,
		useCreateIndex: true
	})
	.then((con) => {
		//console.log(con.connections);
		console.log('DB connection successful');
	});

app.use(pokemonRoutes);

app.all('*', (req, res, next) => {


     console.log("req",req.originalUrl);
	
    const err = new Error('cant find this route')
     err.status = "fail";
    err.statusCode = 410;
    next(err);
    //res.status(404);
	// res.send({
	// 	status: 'fail',
	// 	message: `Can't find ${req.originalUrl} on this server`
	// });
});

app.use((err, req, res, next) => {

    err.status = err.status || "error";
    err.statusCode =  err.statusCode || 500;
    
	res.status(err.statusCode);
    console.log(err.message);

    res.send({
        status:'fail',
        err:err.message
    });
});










// app
// 	.route('/pokemons')
// 	.get(function(req, res) {
// 		Pokemon.find(function(err, foundPokemons) {
// 			if (!err) {
// 				res.send(foundPokemons);
// 			} else {
// 				console.log(err);
// 			}
// 		});
// 	})
// 	.post(function(req, res) {
// 		const Name = req.body.name;

// 		const Type = req.body.type;
// 		const Power = req.body.power;
// 		pokemon1 = Pokemon({
// 			name: Name,
// 			type: Type,
// 			power: Power
// 		});

// 		pokemon1.save(function(err) {
// 			if (!err) {
// 				res.send('successfully added new schema');
// 			} else {
// 				conole.log(err);
// 			}
// 		});
// 	})
// 	.delete(function(req, res) {
// 		Pokemon.deleteMany(function(err) {
// 			if (!err) {
// 				res.send('successfully deleted');
// 			} else {
// 				console.log(err);
// 			}
// 		});
// 	});

// app
// 	.route('/pokemons/:pokemonname')
// 	.get(function(req, res) {
// 		let pn = req.params.pokemonname;
// 		Pokemon.findOne({ name: pn }, function(err, foundPokemon) {
// 			if (!err) {
// 				if (foundPokemon != null) {
// 					res.send(foundPokemon);
// 				} else {
// 					res.send('no such pokemon');
// 				}
// 			} else {
// 				console.log(err);
// 			}
// 		});
// 	})
// 	.put(function(req, res) {
// 		Pokemon.updateOne(
// 			{ name: req.params.pokemonname },
// 			{ name: req.body.name, power: req.body.power, type: req.body.type },
// 			function(err) {
// 				if (!err) {
// 					res.send('successfully updated one ');
// 				} else {
// 					res.send(err);
// 					console.log(err);
// 				}
// 			}
// 		);
// 	})
// 	.patch(function(req, res) {
// 		Pokemon.updateOne({ name: req.params.pokemonname }, { $set: req.body }, function(err) {
// 			if (!err) {
// 				res.send('successfully updated');
// 			} else {
// 				res.send(err);
// 				console.log(err);
// 			}
// 		});
// 	})
// 	.delete(function(req, res) {
// 		Pokemon.deleteOne({ name: req.params.pokemonname }, function(err) {
// 			if (!err) {
// 				res.send('succesfully deleted');
// 			} else {
// 				console.log(err);
// 			}
// 		});
// 	});

app.listen(5000, function() {
	console.log('Server started on port 5000');
});
